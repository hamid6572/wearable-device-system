
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'devuser25',
  applicationName: 'pet-wearable',
  appUid: 'vQ5HZvcnRGjGKkNc2F',
  orgUid: '87a6e96b-7349-4223-aba2-23d9ba8b9e7c',
  deploymentUid: 'ef7c676d-6087-49d1-9a10-5d97a08323a7',
  serviceName: 'pet-wearable',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'pet-wearable-dev-addPet', timeout: 6 };

try {
  const userHandler = require('./src/handlers/pet/addPet.js');
  module.exports.handler = serverlessSDK.handler(userHandler.addPet, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}